import json
import re
import requests
import time
from typing import Dict, List, Any, Optional
from datetime import datetime
from src.models.benchmark import db, BenchmarkTask, LLMModel, BenchmarkEvaluation, BenchmarkRun

class EvaluationEngine:
    """Core engine for running LLM evaluations against benchmark tasks"""
    
    def __init__(self):
        self.supported_providers = {
            'openai': self._call_openai_api,
            'anthropic': self._call_anthropic_api,
            'local': self._call_local_api
        }
    
    def run_benchmark(self, run_id: int) -> Dict[str, Any]:
        """Execute a complete benchmark run"""
        run = BenchmarkRun.query.get(run_id)
        if not run:
            raise ValueError(f"Benchmark run {run_id} not found")
        
        if run.status != 'running':
            raise ValueError(f"Benchmark run {run_id} is not in running status")
        
        model_ids = json.loads(run.model_ids)
        task_categories = json.loads(run.task_categories) if run.task_categories else None
        
        # Get models and tasks
        models = LLMModel.query.filter(LLMModel.id.in_(model_ids)).all()
        
        if task_categories:
            tasks = BenchmarkTask.query.filter(
                BenchmarkTask.category.in_(task_categories),
                BenchmarkTask.is_active == True
            ).all()
        else:
            tasks = BenchmarkTask.query.filter_by(is_active=True).all()
        
        results = []
        completed_tasks = 0
        
        try:
            for model in models:
                for task in tasks:
                    try:
                        # Run evaluation for this model-task pair
                        evaluation_result = self.evaluate_task(model, task)
                        results.append(evaluation_result)
                        completed_tasks += 1
                        
                        # Update run progress
                        run.completed_tasks = completed_tasks
                        db.session.commit()
                        
                        # Add small delay to avoid rate limiting
                        time.sleep(0.1)
                        
                    except Exception as e:
                        print(f"Error evaluating task {task.id} with model {model.id}: {str(e)}")
                        continue
            
            # Mark run as completed
            run.status = 'completed'
            run.completed_at = datetime.utcnow()
            run.results_summary = json.dumps(self._generate_results_summary(results))
            db.session.commit()
            
            return {
                'status': 'completed',
                'total_evaluations': len(results),
                'results_summary': json.loads(run.results_summary)
            }
            
        except Exception as e:
            run.status = 'failed'
            db.session.commit()
            raise e
    
    def evaluate_task(self, model: LLMModel, task: BenchmarkTask) -> Dict[str, Any]:
        """Evaluate a single task with a specific model"""
        
        # Get model response
        model_output = self._get_model_response(model, task.prompt)
        
        # Calculate automated score
        automated_score = self._calculate_automated_score(task, model_output)
        
        # Calculate LLM-as-a-judge score (if applicable)
        llm_judge_score = self._calculate_llm_judge_score(task, model_output)
        
        # Store evaluation result
        evaluation = BenchmarkEvaluation(
            task_id=task.id,
            model_id=model.id,
            model_output=model_output,
            automated_score=automated_score,
            llm_judge_score=llm_judge_score,
            evaluation_metrics=json.dumps({
                'response_length': len(model_output),
                'evaluation_timestamp': datetime.utcnow().isoformat()
            }),
            evaluated_by='system'
        )
        
        db.session.add(evaluation)
        db.session.commit()
        
        return evaluation.to_dict()
    
    def _get_model_response(self, model: LLMModel, prompt: str) -> str:
        """Get response from the specified model"""
        provider = model.provider.lower()
        
        if provider in self.supported_providers:
            return self.supported_providers[provider](model, prompt)
        else:
            raise ValueError(f"Unsupported provider: {provider}")
    
    def _call_openai_api(self, model: LLMModel, prompt: str) -> str:
        """Call OpenAI API (placeholder implementation)"""
        # This would require actual API keys and implementation
        # For now, return a placeholder response
        return f"[PLACEHOLDER] OpenAI {model.name} response to: {prompt[:100]}..."
    
    def _call_anthropic_api(self, model: LLMModel, prompt: str) -> str:
        """Call Anthropic API (placeholder implementation)"""
        # This would require actual API keys and implementation
        # For now, return a placeholder response
        return f"[PLACEHOLDER] Anthropic {model.name} response to: {prompt[:100]}..."
    
    def _call_local_api(self, model: LLMModel, prompt: str) -> str:
        """Call local model API"""
        try:
            if model.api_endpoint:
                response = requests.post(
                    model.api_endpoint,
                    json={'prompt': prompt, 'model': model.name},
                    timeout=30
                )
                response.raise_for_status()
                return response.json().get('response', '')
            else:
                return f"[LOCAL] {model.name} response to: {prompt[:100]}..."
        except Exception as e:
            return f"[ERROR] Failed to get response from {model.name}: {str(e)}"
    
    def _calculate_automated_score(self, task: BenchmarkTask, model_output: str) -> Optional[float]:
        """Calculate automated score based on task type and expected output"""
        if not task.expected_output:
            return None
        
        task_type = task.task_type.lower()
        
        if task_type == 'multiple_choice':
            return self._score_multiple_choice(task.expected_output, model_output)
        elif task_type == 'exact_match':
            return self._score_exact_match(task.expected_output, model_output)
        elif task_type == 'contains':
            return self._score_contains(task.expected_output, model_output)
        elif task_type == 'code_execution':
            return self._score_code_execution(task.expected_output, model_output)
        else:
            # For open-ended tasks, return None (requires human or LLM judge)
            return None
    
    def _score_multiple_choice(self, expected: str, actual: str) -> float:
        """Score multiple choice answers"""
        # Extract letter/number from both expected and actual
        expected_choice = re.search(r'[A-Za-z0-9]', expected)
        actual_choice = re.search(r'[A-Za-z0-9]', actual)
        
        if expected_choice and actual_choice:
            return 1.0 if expected_choice.group().upper() == actual_choice.group().upper() else 0.0
        return 0.0
    
    def _score_exact_match(self, expected: str, actual: str) -> float:
        """Score exact string match"""
        return 1.0 if expected.strip().lower() == actual.strip().lower() else 0.0
    
    def _score_contains(self, expected: str, actual: str) -> float:
        """Score if expected text is contained in actual"""
        return 1.0 if expected.lower() in actual.lower() else 0.0
    
    def _score_code_execution(self, expected: str, actual: str) -> float:
        """Score code execution (placeholder - would need actual execution)"""
        # This would require safe code execution environment
        # For now, just check if code looks syntactically valid
        try:
            compile(actual, '<string>', 'exec')
            return 0.5  # Partial credit for syntactically valid code
        except SyntaxError:
            return 0.0
    
    def _calculate_llm_judge_score(self, task: BenchmarkTask, model_output: str) -> Optional[float]:
        """Calculate score using LLM-as-a-judge approach"""
        # This would use a separate LLM to evaluate the response
        # For now, return a placeholder score based on response length and task type
        
        if task.task_type in ['open_ended', 'creative_writing', 'argumentation']:
            # Simple heuristic: longer responses get higher scores (up to a point)
            length_score = min(len(model_output) / 1000, 1.0)
            
            # Check for some quality indicators
            quality_indicators = [
                'because', 'therefore', 'however', 'furthermore', 'in conclusion',
                'for example', 'specifically', 'moreover', 'nevertheless'
            ]
            
            indicator_score = sum(1 for indicator in quality_indicators 
                                if indicator in model_output.lower()) / len(quality_indicators)
            
            return (length_score + indicator_score) / 2
        
        return None
    
    def _generate_results_summary(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate summary statistics from evaluation results"""
        if not results:
            return {}
        
        # Calculate average scores
        automated_scores = [r['automated_score'] for r in results if r['automated_score'] is not None]
        llm_judge_scores = [r['llm_judge_score'] for r in results if r['llm_judge_score'] is not None]
        
        summary = {
            'total_evaluations': len(results),
            'avg_automated_score': sum(automated_scores) / len(automated_scores) if automated_scores else None,
            'avg_llm_judge_score': sum(llm_judge_scores) / len(llm_judge_scores) if llm_judge_scores else None,
            'score_distribution': {
                'automated': self._get_score_distribution(automated_scores),
                'llm_judge': self._get_score_distribution(llm_judge_scores)
            }
        }
        
        return summary
    
    def _get_score_distribution(self, scores: List[float]) -> Dict[str, int]:
        """Get distribution of scores in bins"""
        if not scores:
            return {}
        
        bins = {'0.0-0.2': 0, '0.2-0.4': 0, '0.4-0.6': 0, '0.6-0.8': 0, '0.8-1.0': 0}
        
        for score in scores:
            if score < 0.2:
                bins['0.0-0.2'] += 1
            elif score < 0.4:
                bins['0.2-0.4'] += 1
            elif score < 0.6:
                bins['0.4-0.6'] += 1
            elif score < 0.8:
                bins['0.6-0.8'] += 1
            else:
                bins['0.8-1.0'] += 1
        
        return bins

# Utility functions for data loading
class DataLoader:
    """Utility class for loading benchmark data"""
    
    @staticmethod
    def load_sample_tasks():
        """Load sample benchmark tasks into the database"""
        sample_tasks = [
            {
                'category': 'reasoning',
                'subcategory': 'mathematical_reasoning',
                'task_type': 'exact_match',
                'title': 'Basic Algebra Problem',
                'description': 'Solve a basic algebraic equation',
                'prompt': 'Solve for x: 2x + 5 = 13. Provide only the numerical answer.',
                'expected_output': '4',
                'difficulty_level': 2
            },
            {
                'category': 'reasoning',
                'subcategory': 'logical_puzzles',
                'task_type': 'multiple_choice',
                'title': 'Logic Puzzle',
                'description': 'Solve a basic logic puzzle',
                'prompt': 'If all roses are flowers, and some flowers are red, which of the following must be true? A) All roses are red B) Some roses are red C) No roses are red D) Cannot be determined',
                'expected_output': 'D',
                'difficulty_level': 3
            },
            {
                'category': 'language',
                'subcategory': 'creative_writing',
                'task_type': 'open_ended',
                'title': 'Short Story Writing',
                'description': 'Write a creative short story',
                'prompt': 'Write a 200-word short story about a time traveler who accidentally changes something small in the past.',
                'expected_output': None,
                'difficulty_level': 4
            },
            {
                'category': 'ethics',
                'subcategory': 'bias_detection',
                'task_type': 'contains',
                'title': 'Bias Detection',
                'description': 'Identify bias in a given text',
                'prompt': 'Analyze this job description for potential bias: "We are looking for a young, energetic developer who can work long hours and fit in with our team of guys." What biases can you identify?',
                'expected_output': 'age bias',
                'difficulty_level': 3
            }
        ]
        
        for task_data in sample_tasks:
            task = BenchmarkTask(**task_data, created_by='system')
            db.session.add(task)
        
        db.session.commit()
        print(f"Loaded {len(sample_tasks)} sample tasks")
    
    @staticmethod
    def load_sample_models():
        """Load sample LLM models into the database"""
        sample_models = [
            {
                'name': 'GPT-4',
                'provider': 'OpenAI',
                'version': 'gpt-4-0125-preview',
                'model_type': 'chat',
                'context_length': 128000
            },
            {
                'name': 'Claude-3-Opus',
                'provider': 'Anthropic',
                'version': 'claude-3-opus-20240229',
                'model_type': 'chat',
                'context_length': 200000
            },
            {
                'name': 'Local-LLaMA',
                'provider': 'Local',
                'version': 'llama-2-7b',
                'model_type': 'chat',
                'context_length': 4096,
                'api_endpoint': 'http://localhost:8000/generate'
            }
        ]
        
        for model_data in sample_models:
            model = LLMModel(**model_data)
            db.session.add(model)
        
        db.session.commit()
        print(f"Loaded {len(sample_models)} sample models")

