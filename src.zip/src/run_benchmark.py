"""
Minimal CLI to run SCLEB locally.

Usage:
    python run_benchmark.py --run-id 1
    # or, if you only want to evaluate one model on one task:
    python run_benchmark.py --model 1 --task 3
"""
import argparse
from datetime import datetime
import json

# make local imports work no matter where the user calls the script from
import os, sys
ROOT = os.path.dirname(__file__)
sys.path.insert(0, ROOT)

from src.evaluation_engine import EvaluationEngine
from src.models.benchmark import db, BenchmarkTask, LLMModel, BenchmarkRun
from src.main import app           # re-uses your existing SQLite config

engine = EvaluationEngine()


def _single_eval(model_id: int, task_id: int):
    with app.app_context():
        model = LLMModel.query.get_or_404(model_id)
        task  = BenchmarkTask.query.get_or_404(task_id)
        result = engine.evaluate_task(model, task)
        print("\n🎉  Single-evaluation result")
        for k, v in result.items():
            print(f"{k:18}: {v}")


def _full_run(run_id: int):
    with app.app_context():
        run = BenchmarkRun.query.get_or_404(run_id)
        if run.status == "pending":
            run.status       = "running"
            run.started_at   = datetime.utcnow()
            db.session.commit()

        summary = engine.run_benchmark(run_id)
        print("\n✅  Benchmark finished")
        print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run SCLEB locally")
    group  = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--run-id",  type=int, help="ID from benchmark_runs table")
    group.add_argument("--model",   type=int, help="Model ID for single evaluation")
    parser.add_argument("--task",   type=int, help="Task  ID for single evaluation")

    args = parser.parse_args()

    if args.run_id:
        _full_run(args.run_id)
    else:
        if not args.task:
            parser.error("--model requires --task")
        _single_eval(args.model, args.task)
