"""
Register a new model in the SCLEB database.

Usage 1 – JSON file:
    python add_model.py --json my_model.json

Usage 2 – CLI flags:
    python add_model.py \
        --name "My-LLaMA" \
        --provider local \
        --version v0.1 \
        --endpoint http://localhost:8000/generate \
        --context 4096
"""
import json, argparse, os, sys
ROOT = os.path.dirname(__file__)
sys.path.insert(0, ROOT)

from src.main import app
from src.models.benchmark import db, LLMModel


def add_model_from_dict(d: dict):
    required = {"name", "provider"}
    if not required.issubset(d):
        missing = ", ".join(required - set(d))
        raise ValueError(f"Missing required field(s): {missing}")

    model = LLMModel.query.filter_by(name=d["name"]).first()
    if model:
        print(f"🔁  Model '{d['name']}' already exists (id={model.id}). Updating info.")
        for k, v in d.items():
            setattr(model, k, v)
    else:
        model = LLMModel(**d)
        db.session.add(model)

    db.session.commit()
    print(f"✅  Model saved with id={model.id}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--json", help="Path to a JSON file describing the model")
    p.add_argument("--name")
    p.add_argument("--provider")
    p.add_argument("--version")
    p.add_argument("--endpoint")
    p.add_argument("--model-type", default="chat")
    p.add_argument("--context", type=int, default=None)
    args = p.parse_args()

    if args.json:
        with open(args.json, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = {
            "name": args.name,
            "provider": args.provider,
            "version": args.version,
            "api_endpoint": args.endpoint,
            "model_type": args.model_type,
            "context_length": args.context,
        }

    with app.app_context():
        add_model_from_dict({k: v for k, v in data.items() if v is not None})


if __name__ == "__main__":
    main()
