#!/usr/bin/env python3
"""
Script to load sample data into the SCLEB benchmark database
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from src.models.benchmark import BenchmarkTask, LLMModel
from src.evaluation_engine import DataLoader
from src.main import app
from src.models.user import db

def load_sample_data():
    """Load sample tasks and models into the database"""
    with app.app_context():
        # Create tables if they don't exist
        db.create_all()
        
        print("Loading sample tasks...")
        DataLoader.load_sample_tasks()
        
        print("Loading sample models...")
        DataLoader.load_sample_models()
        
        print("Sample data loaded successfully!")
        
        # Print summary
        task_count = BenchmarkTask.query.count()
        model_count = LLMModel.query.count()
        
        print(f"Total tasks: {task_count}")
        print(f"Total models: {model_count}")

if __name__ == "__main__":
    load_sample_data()

