from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class BenchmarkTask(db.Model):
    """Model for storing benchmark tasks"""
    __tablename__ = 'benchmark_tasks'
    
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(100), nullable=False)  # e.g., 'reasoning', 'language', 'ethics', 'real_world'
    subcategory = db.Column(db.String(100), nullable=False)  # e.g., 'scientific_reasoning', 'math_reasoning'
    task_type = db.Column(db.String(100), nullable=False)  # e.g., 'multiple_choice', 'open_ended', 'code_generation'
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    prompt = db.Column(db.Text, nullable=False)
    expected_output = db.Column(db.Text)  # Ground truth answer
    evaluation_criteria = db.Column(db.Text)  # JSON string of evaluation criteria
    difficulty_level = db.Column(db.Integer, default=1)  # 1-5 scale
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.String(100))  # Expert who created the task
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    evaluations = db.relationship('BenchmarkEvaluation', backref='task', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'category': self.category,
            'subcategory': self.subcategory,
            'task_type': self.task_type,
            'title': self.title,
            'description': self.description,
            'prompt': self.prompt,
            'expected_output': self.expected_output,
            'evaluation_criteria': json.loads(self.evaluation_criteria) if self.evaluation_criteria else {},
            'difficulty_level': self.difficulty_level,
            'created_at': self.created_at.isoformat(),
            'created_by': self.created_by,
            'is_active': self.is_active
        }

class LLMModel(db.Model):
    """Model for storing LLM information"""
    __tablename__ = 'llm_models'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    provider = db.Column(db.String(50), nullable=False)  # e.g., 'OpenAI', 'Anthropic', 'Google'
    version = db.Column(db.String(50))
    api_endpoint = db.Column(db.String(200))
    model_type = db.Column(db.String(50))  # e.g., 'chat', 'completion'
    context_length = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    evaluations = db.relationship('BenchmarkEvaluation', backref='model', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'provider': self.provider,
            'version': self.version,
            'api_endpoint': self.api_endpoint,
            'model_type': self.model_type,
            'context_length': self.context_length,
            'created_at': self.created_at.isoformat(),
            'is_active': self.is_active
        }

class BenchmarkEvaluation(db.Model):
    """Model for storing evaluation results"""
    __tablename__ = 'benchmark_evaluations'
    
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('benchmark_tasks.id'), nullable=False)
    model_id = db.Column(db.Integer, db.ForeignKey('llm_models.id'), nullable=False)
    model_output = db.Column(db.Text, nullable=False)
    automated_score = db.Column(db.Float)  # 0-1 scale
    human_score = db.Column(db.Float)  # 0-1 scale
    llm_judge_score = db.Column(db.Float)  # 0-1 scale
    evaluation_metrics = db.Column(db.Text)  # JSON string of detailed metrics
    evaluation_notes = db.Column(db.Text)
    evaluated_at = db.Column(db.DateTime, default=datetime.utcnow)
    evaluated_by = db.Column(db.String(100))  # Human evaluator or system
    
    def to_dict(self):
        return {
            'id': self.id,
            'task_id': self.task_id,
            'model_id': self.model_id,
            'model_output': self.model_output,
            'automated_score': self.automated_score,
            'human_score': self.human_score,
            'llm_judge_score': self.llm_judge_score,
            'evaluation_metrics': json.loads(self.evaluation_metrics) if self.evaluation_metrics else {},
            'evaluation_notes': self.evaluation_notes,
            'evaluated_at': self.evaluated_at.isoformat(),
            'evaluated_by': self.evaluated_by
        }

class BenchmarkRun(db.Model):
    """Model for storing benchmark run sessions"""
    __tablename__ = 'benchmark_runs'
    
    id = db.Column(db.Integer, primary_key=True)
    run_name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    model_ids = db.Column(db.Text)  # JSON array of model IDs
    task_categories = db.Column(db.Text)  # JSON array of categories to test
    status = db.Column(db.String(50), default='pending')  # pending, running, completed, failed
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    total_tasks = db.Column(db.Integer, default=0)
    completed_tasks = db.Column(db.Integer, default=0)
    results_summary = db.Column(db.Text)  # JSON string of aggregated results
    
    def to_dict(self):
        return {
            'id': self.id,
            'run_name': self.run_name,
            'description': self.description,
            'model_ids': json.loads(self.model_ids) if self.model_ids else [],
            'task_categories': json.loads(self.task_categories) if self.task_categories else [],
            'status': self.status,
            'started_at': self.started_at.isoformat(),
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'total_tasks': self.total_tasks,
            'completed_tasks': self.completed_tasks,
            'results_summary': json.loads(self.results_summary) if self.results_summary else {}
        }

