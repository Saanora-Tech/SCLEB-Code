"""
Create a BenchmarkRun row quickly.

Examples
--------
# run all active tasks on models 1 and 3
python create_run.py --name "my-first-run" --models 1 3

# only reasoning + ethics categories
python create_run.py --name narrow-run --models 2 --cats reasoning ethics
"""
import argparse, json, os, sys
from datetime import datetime

ROOT = os.path.dirname(__file__)
sys.path.insert(0, ROOT)

from src.main import app
from src.models.benchmark import db, BenchmarkRun, LLMModel, BenchmarkTask


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--name", required=True, help="Human-friendly run name")
    p.add_argument("--desc", default="")
    p.add_argument("--models", nargs="+", type=int, required=True, help="Model IDs")
    p.add_argument("--cats", nargs="*", help="Task categories (default = all active)")
    args = p.parse_args()

    with app.app_context():
        # sanity-check models
        bad = [m for m in args.models if not LLMModel.query.get(m)]
        if bad:
            raise SystemExit(f"❌ Unknown model ID(s): {bad}")

        if args.cats:
            # see that categories exist (optional)
            known = {t.category for t in BenchmarkTask.query.with_entities(BenchmarkTask.category).distinct()}
            missing = set(args.cats) - known
            if missing:
                raise SystemExit(f"❌ Unknown category name(s): {missing}")

        run = BenchmarkRun(
            run_name=args.name,
            description=args.desc,
            model_ids=json.dumps(args.models),
            task_categories=json.dumps(args.cats) if args.cats else None,
            status="pending",
            started_at=None,
            total_tasks=0,
            completed_tasks=0,
        )
        db.session.add(run)
        db.session.commit()
        print(f"✅  BenchmarkRun created with id={run.id}")
        print("👉  Start it with:")
        print(f"    python run_benchmark.py --run-id {run.id}")


if __name__ == "__main__":
    main()
