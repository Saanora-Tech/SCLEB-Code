"""
Register a new benchmark task.

Usage A – JSON file:
    python add_task.py --json my_task.json

Usage B – CLI flags (quick exact-match or MCQ demo):
    python add_task.py \
        --category reasoning \
        --subcategory math \
        --type exact_match \
        --title "2+2" \
        --prompt "What is 2 + 2?" \
        --expect "4" \
        --difficulty 1
"""
import json, argparse, os, sys
from datetime import datetime

ROOT = os.path.dirname(__file__)
sys.path.insert(0, ROOT)

from src.main import app
from src.models.benchmark import db, BenchmarkTask


def add_task_from_dict(d: dict):
    required = {"category", "subcategory", "task_type", "title", "prompt"}
    if not required.issubset(d):
        missing = ", ".join(required - set(d))
        raise ValueError(f"Missing required field(s): {missing}")

    task = BenchmarkTask(**d, created_by="user")
    db.session.add(task)
    db.session.commit()
    print(f"✅  Task saved with id={task.id}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--json", help="Path to task JSON file")
    p.add_argument("--category")
    p.add_argument("--subcategory")
    p.add_argument("--type", dest="task_type")
    p.add_argument("--title")
    p.add_argument("--prompt")
    p.add_argument("--expect", dest="expected_output")
    p.add_argument("--difficulty", type=int, default=1)
    args = p.parse_args()

    if args.json:
        with open(args.json, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = {
            "category": args.category,
            "subcategory": args.subcategory,
            "task_type": args.task_type,
            "title": args.title,
            "prompt": args.prompt,
            "expected_output": args.expected_output,
            "difficulty_level": args.difficulty,
        }

    with app.app_context():
        add_task_from_dict({k: v for k, v in data.items() if v is not None})


if __name__ == "__main__":
    main()
